//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sample.rc
//
#define IDS_FILTERSTRING                1
#define IDS_INITDONE                    2
#define IDS_DRVTEST                     3
#define IDM_ABOUT                       100
#define IDM_FILE_OPEN                   101
#define ID_FILE_EXIT                    102
#define IDM_OPEN_DRIVER                 103
#define IDM_CLOSE_DRIVER                104
#define IDD_DIALOG_DATAEX               106
#define IDM_OPEN_2_CIRCUITS             106
#define IDM_FUNCTIONS_DATAEXCHANGE      107
#define IDM_CLOSE_2_CIRCUITS            108
#define IDC_CHECK_IN3                   1000
#define IDC_CHECK_IN2                   1001
#define IDC_CHECK_IN1                   1002
#define IDC_CHECK_IN0                   1003
#define IDC_CHECK_OUT3                  1004
#define IDC_CHECK_OUT2                  1005
#define IDC_CHECK_OUT1                  1006
#define IDC_CHECK_OUT0                  1007
#define IDC_EDIT_SLAVE_ADDR             1009
#define IDC_CHECK_CIRC2                 1010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         109
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
