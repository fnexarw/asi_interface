Installation of AS-Interface PC2 cards

If there is one or more AS-Interface PC2 cards (or AS-Interface PC/104 cards)
in your PC you have to activate these devices now. Select the
devices in the dialogbox "AS-Interface PC2 Port" and click "On".

If there is no AS-Interface PC2 card (or AS-Interface PC/104 card) installed,
click "Cancel".
